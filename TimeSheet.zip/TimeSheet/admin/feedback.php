<!DOCTYPE html>
<?php $title = 'Feedback';?>
<html lang="en">
    <?php include 'includes/header.php';?>
    <style>    
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
</style>
<body>
    <div id="content">
        <h4>Feedback</h4>
        <?php
        $feedback = "select * from feedback";
        $exe = mysqli_query($connection, $feedback);
        $rows = mysqli_num_rows($exe);

        if($rows > 0){?>
            <table>
                <tr class="col-4">
                    <th>Date</th>
                    <th>Message</th>    
                </tr>
                    <?php while($message = mysqli_fetch_assoc($exe)){?>
                        <tr class="col-8">
                        <td><?php echo date('Y-m-d', strtotime($message['date'])) ?></td>
                    <td><?php echo $message['message']; ?></td>
                    </tr>
                    <?php }?>
            </table>
        <?php }
        ?>
    </div>
    <script src="main.js"></script>
    <script>
    </script>
</body>
<?php include 'includes/footer.php' ?>
</html>