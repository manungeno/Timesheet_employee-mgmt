<head>
    <?php session_start();
    include 'db-connection/connection.php'; 
    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../icon.png">
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="libraries/css/bootstrap.min.css">
    <link rel="stylesheet" href="libraries/fontawesome/css/all.css">
    <script src="libraries/jquery-3.6.0.min.js"></script>
    <title><?php echo $title?></title>

    <?php
    if(isset($_SESSION['admin-login-time']) && time() - $_SESSION['admin-login-time'] <= 21600 && isset($_SESSION['admin-username'])){
    ?>

    <div class="header">
        <nav id="navbar">
            <div id="title" class="mx-3 d-flex flex-row"><i class="fa-solid fa-bars" style="margin-right: 15px"></i>TimeSheet</div>
            <div id="links" class="mx-3">
                <a href="profile.php"><i class="fa-solid fa-circle-user"></i> <?php echo $_SESSION['admin-username']; ?></a>
                <a href="logout.php" style="margin-left: 15px;"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</a>
            </div>
        </nav>
    </div>
    <div class="sidebar">
        <div class="top-part mb-3">
            <h6>Administrator</h6>
            <p><span></span>Online</p>
        </div>
        <div id="pages">
            <a href="./"><i class="fa-solid fa-house"></i> Dashboard</a>
            <a href="tasks.php"><i class="fa-solid fa-briefcase"></i> Tasks Done</a>
            <a href="#" id="dropdown"><i class="fa-solid fa-users"></i> Employees</a>
                <div id="dropdown-links">
                    <a href="all-employees.php"><i class="fa-solid fa-users"></i> All Employees</a>
                    <a href="present.php"><i class="fa-solid fa-users"></i> Present Today</a>
                    <a href="leave.php"><i class="fa-solid fa-users"></i> Employees in leave</a>
                    <a href="unapproved.php"><i class="fa-solid fa-users"></i> Unapproved Employees</a>
                </div>
            <a href="branches.php"><i class="fa-solid fa-building"></i> Branches</a>
            <a href="department.php"><i class="fas fa-table"></i> Departments</a>
            <a href="admins.php"><i class="fa-solid fa-user-lock"></i> Admins</a>
            <a href="feedback.php"><i class="fa-regular fa-comment-dots"></i> Feedback</a>
            
        </div>
    </div>
    <?php }
    else{
        session_unset();
        session_destroy();
        echo '<script>window.location.assign("login.html")</script>';
    }
    ?>
</head>