<?php
$username = 'root';
$password = '';
$host = 'localhost';
$db_name = 'amtech';

$connection = new mysqli($host, $username, $password, $db_name);
//fetching branches
function fetch_branches(){
    global $connection;
    $sql = "SELECT * FROM branch";
    $run = mysqli_query($connection, $sql);?>
    <tr>
        <th>Branch Number</th>
        <th>Branch Name</th>
        <th>Actions</th>
    </tr>

    <?php while($details = mysqli_fetch_assoc($run)){?>
         <tr>
            <td><?php echo $details['branch_number']?></td>
            <td><?php echo $details['branch_name']?></td>
            <td><button class="btn btn-sm btn-danger" value="<?php echo $details['id']?>">Delete</button></td>
        </tr>
<?php }
}

//fetching departments
function fetch_departments(){
    global $connection;
    $sql = "SELECT * FROM department";
    $run = mysqli_query($connection, $sql);?>
    <tr>
        <th>Department Number</th>
        <th>Department Name</th>
        <th>Actions</th>
    </tr>

    <?php while($details = mysqli_fetch_assoc($run)){?>
         <tr>
            <td><?php echo $details['department_number']?></td>
            <td><?php echo $details['department_name']?></td>
            <td><button class="btn btn-sm btn-danger" value="<?php echo $details['id']?>">Delete</button></td>
        </tr>
<?php }
}

//fetching unapproved employees
function unapproved(){
    global $connection;
    $sql = "SELECT * FROM employee WHERE approval = 'Not Approved'";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);?>
            <tr>
                <th>Employee Name</th>
                <th>Employee Department</th>
                <th>Approval</th>
                <th>Phone Number</th>
                <th>Actions</th>
            </tr>
<?php
        if($rows > 0){
            while($details = mysqli_fetch_assoc($run)){?>
                <tr>
                    <td><?php echo $details['fname'].' '.$details['lname']?></td>
                    <td><?php echo $details['department']?></td>
                    <td><?php echo $details['approval']?></td>
                    <td><?php echo $details['phone']?></td>
                    <td><button class="btn btn-sm btn-success" value="<?php echo $details['employee_id']?>">Approve</button></td>
                </tr>
            <?php }
        }
        else{?>
            <tr><td>No employee</td></tr>
      <?php }
}

//fetching all employees
function all_employees(){
    global $connection;
    $sql = "SELECT * FROM employee WHERE approval ='Approved'";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);?>
            <tr>
                <th>Employee Name</th>
                <th>Employee Department</th>
                <th>Phone Number</th>
                <th>In Leave</th>
                <th>Actions</th>
            </tr>
<?php
        if($rows > 0){
            while($details = mysqli_fetch_assoc($run)){?>
                <tr>
                    <td><?php echo $details['fname'].' '.$details['lname']?></td>
                    <td><?php echo $details['department']?></td>
                    <td><?php echo $details['phone']?></td>
                    <td><?php echo $details['under_leave']?></td>
                    <td><button class="btn btn-sm btn-danger delete" value="<?php echo $details['employee_id']?>">Delete</button><?php if($details['under_leave'] == 'No'){?><button value="<?php echo $details['employee_id']?>" class="btn btn-sm btn-warning leave">Leave</button><?php }?></td>
                </tr>
            <?php }
        }
        else{?>
            <tr><td>No employee</td></tr>
      <?php }
}

//fetching all employees under leave
function under_leave(){
    global $connection;
    $sql = "SELECT * FROM employee WHERE under_leave ='Yes'";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);?>
            <tr>
                <th>Employee Name</th>
                <th>Employee Department</th>
                <th>Phone Number</th>
                <th>Actions</th>
            </tr>
<?php
        if($rows > 0){
            while($details = mysqli_fetch_assoc($run)){?>

                <tr>
                    <td><?php echo $details['fname'].' '.$details['lname']?></td>
                    <td><?php echo $details['department']?></td>
                    <td><?php echo $details['phone']?></td>
                    <td><button class="btn btn-sm btn-success" value="<?php echo $details['employee_id']?>">Back to work</button></td>
                </tr>
            <?php }
        }
        else{?>
            <tr><td>No employee in leave</td></tr>
      <?php }
}

//Total employees
function total_employees(){
    global $connection;
    $sql = "SELECT fname FROM employee WHERE approval ='Approved'";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);
        echo $rows;
}

//present employees today
function present_today(){
    global $connection;
    $sql = "SELECT report_id FROM report WHERE date = CURDATE()";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);
        echo $rows;
}

//Total Branches
function total_branches(){
    global $connection;
    $sql = "SELECT branch_number FROM branch";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);
        echo $rows;
}


//department selection for the employee
function department_selection(){
    global $connection;
    $sql = "SELECT * FROM department";
    $run = mysqli_query($connection, $sql);
    
    while($details = mysqli_fetch_assoc($run)){?>
        <option value="<?php echo $details['department_name']?>"><?php echo $details['department_name']?></option>
    <?php }
}

//branch selection
function branch_selection(){
    global $connection;
    $sql = "SELECT * FROM branch";
    $run = mysqli_query($connection, $sql);
    
    while($details = mysqli_fetch_assoc($run)){?>
        <option value="<?php echo $details['branch_name']?>"><?php echo $details['branch_name']?></option>
    <?php }
}

//fetching tasks for admin
function tasks_for_admin(){
    global $connection;
    $sql = "SELECT * FROM report AS r JOIN employee AS e ON R.employee_id = e. employee_id order by time_uploaded DESC";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);
        if($rows > 0){
            while($details = mysqli_fetch_array($run)){ ?>

            <div id="row">
                <div id="name"><p><button class="btn btn-sm mb-1"><i class="fa-solid fa-plus"></i><i class="fa-solid fa-minus"></i></button><?php echo $details['fname'].' '. $details['lname']?></p></div>
                <div id="working-hours"><p>From: <?php echo $details['time_in']?></p></div>
                <div id="working-hours"><p>To: <?php echo $details['timeout']?></p></div>
                <div id="working-hours"><p><?php echo $details['place_of_work']?></p></div>
                <div id="remarks"><?php echo $details['remarks']?></div>
            </div>
            <?php }
        }
        else{?>
            <div id="row">No task...</div>
      <?php }
}

//present employees in detail
function present_today2(){
    global $connection;
    $sql = "SELECT * FROM report AS r JOIN employee AS e ON R.employee_id = e. employee_id WHERE date = CURDATE() order by time_uploaded ASC";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);?>
            <tr>
                <th>Employee Name</th>
                <th>Employee Department</th>
                <th>Time in</th>
                <th>Time Out</th>
                <th>Phone Number</th>
            </tr>
<?php
        if($rows > 0){
            while($details = mysqli_fetch_assoc($run)){?>
                <tr>
                    <td><?php echo $details['fname'].' '.$details['lname']?></td>
                    <td><?php echo $details['department']?></td>
                    <td><?php echo $details['time_in']?></td>
                    <td><?php echo $details['timeout']?></td>
                    <td><?php echo $details['phone']?></td>
                </tr>
            <?php }
        }
        else{?>
            <tr><td>No employee was present today</td></tr>
      <?php }
}

//fetching admins
function fetch_admins(){
    global $connection;
    $sql = "SELECT * FROM admin";
    $run = mysqli_query($connection, $sql);?>
    <tr>
        <th>Admin Name</th>
        <th>Admin Email</th>
        <th>Actions</th>
    </tr>

    <?php while($details = mysqli_fetch_assoc($run)){?>
         <tr>
            <td><?php echo $details['username']?></td>
            <td><?php echo $details['email']?></td>
            <td><button class="btn btn-sm btn-danger" value="<?php echo $details['id']?>">Delete</button></td>
        </tr>
<?php }
}
?>