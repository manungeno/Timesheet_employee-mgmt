<!DOCTYPE html>
<?php $title = 'Dashboard';?>
<html lang="en">
    <?php include 'includes/header.php';?>
<body>
<?php include 'functions/functions.php';?>
    <div id="content">
        <h4>Dashboard</h4>
        <div class="analysis">
            <div id="total-employees"><i class="fa-solid fa-users"></i><span>Total Employees</span><p><?php total_employees()?></p></div>
            <div id="employees-today"><i class="fa-solid fa-users"></i><span>Employees Present Today</span><p><?php present_today()?></p></div>
            <div id="total-branches"><i class="fa-solid fa-building"></i><span>Total Branches</span><p><?php total_branches()?></p></div>
        </div>
    </div>
    <script src="main.js"></script>
</body>
<?php include 'includes/footer.php' ?>
</html>