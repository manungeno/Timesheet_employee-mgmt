-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2023 at 10:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amtech`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'Emmanuel Ngeno', 'emmanuelngeno23@gmail.com', '3171');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(11) NOT NULL,
  `branch_number` varchar(50) NOT NULL,
  `branch_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `branch_number`, `branch_name`) VALUES
(10, 'b334', 'Molo'),
(14, 'b001', 'Ngong'),
(15, 'c100', 'Nairobi');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department_number` varchar(100) NOT NULL,
  `department_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_number`, `department_name`) VALUES
(9, '100', 'ICT'),
(10, '101', 'Procurement '),
(11, '102', 'HR'),
(12, '103', 'Finance'),
(13, '104', 'Security '),
(14, '105', 'Sales and marketing'),
(15, '106', 'Management'),
(16, '107', 'Data management');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `approval` text NOT NULL,
  `under_leave` text NOT NULL,
  `department` text NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `username`, `fname`, `lname`, `email`, `approval`, `under_leave`, `department`, `phone`, `password`) VALUES
(28, 'Manuu', 'Emmanuel', 'Ngeno', 'emmanuelngeno23@gmail.com', 'Approved', 'No', 'ICT', 719191921, '$2y$10$XkdTzny6ozCYB6Vw9rXXuuM8ygBGe6z3Hc2y2UHgIPjTQdg/56.XW'),
(29, 'mannuela', 'Nathan', 'Langat', 'nathankipronolangat@gmail.com', 'Approved', 'No', 'ICT', 790515678, '$2y$10$a4jL/SVf.JB3uuK0BwFB5eJmgOCQd6ts84cvPGcy3hUd6ZyxYKcOm'),
(30, 'petaa', 'peter', 'langat', 'peterkibet147@gmail.com', 'Approved', 'No', 'ICT', 729221328, '$2y$10$urppoTusNc7xy0q52kmMkObWpy1DWBW/0UgKlS2z1oTFgMQkSLT6i'),
(31, 'Psigei', 'Pius', 'Sigei', 'psigei@amtechafrica.com', 'Approved', 'No', 'ICT', 722871556, '$2y$10$Foadd9WTVLFefIgqCYEiv.Da/kvL5x0V7T/d/KWkyzE4lckm6mAh6'),
(32, '18670', 'Nathan', 'Ngeno', 'qwerty123@gmail.com', 'Approved', 'No', 'Finance', 719191921, '$2y$10$T4Lr1yZyjgMCc/YtXNNrc.JIRtpe8lWBevmAkyEoZL.DG1R7R9T/e');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time_in` time NOT NULL,
  `place_of_work` text NOT NULL,
  `remarks` longtext NOT NULL,
  `timeout` time NOT NULL DEFAULT current_timestamp(),
  `time_uploaded` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `employee_id`, `date`, `time_in`, `place_of_work`, `remarks`, `timeout`, `time_uploaded`) VALUES
(24, 28, '2023-07-04', '07:57:00', 'Ngong', '<p>I was busy reloading the system with the doing on the field I was assigned&nbsp;</p>', '13:54:54', '2023-07-04 10:54:54'),
(25, 29, '2023-07-03', '10:02:00', 'Kakamega', '<p>We are always working together to make sure all are put together and straight things happen.</p>', '14:03:11', '2023-07-04 11:03:11'),
(26, 29, '2023-07-04', '08:30:00', 'Ngong', '<p>Nathan Kiprono is working hard to maintain the systems of Amtech technologyies&nbsp;</p>', '14:43:30', '2023-07-04 11:43:30'),
(27, 30, '2023-07-04', '12:00:00', 'Nairobi', '<p>qurewfoweygiuipif0werjfj</p>', '15:01:55', '2023-07-04 12:01:55'),
(28, 31, '2023-07-06', '10:23:00', 'Ngong', '<p>Am in Meru county training of SACCOS and FPOS&nbsp;</p>', '10:25:08', '2023-07-06 07:25:08'),
(29, 28, '2023-07-09', '10:38:00', 'Ngong', '<p>Am working hard to make the changes I was required to perform before the end of this week.</p>', '10:39:19', '2023-07-10 07:39:19'),
(30, 28, '2023-01-01', '10:39:00', 'Nairobi', '<p>I was training the new incoming workers in our institution to strive to make the work start as required in the office.</p>', '10:40:58', '2023-07-10 07:40:58'),
(31, 28, '2023-07-10', '10:36:00', 'Ngong', '<p>No need to working manually and the technology environment has enhance which can assist anyone willing and ready to use it.</p>', '10:43:32', '2023-07-10 07:43:32'),
(32, 31, '2023-07-02', '10:55:00', 'Nairobi', '<p>I attended all my workers t check on the projects i assigned them some few days ago.</p>', '10:57:48', '2023-07-10 07:57:48'),
(33, 31, '2023-07-10', '11:16:00', 'Ngong', '<p>xdthyuji hk hkI attended all my workers t check on the projects i assigned them some few days ago.</p>', '11:16:34', '2023-07-10 08:16:34'),
(34, 32, '2023-07-14', '09:55:00', 'Ngong', '<p>we install the project on the company servers</p>', '11:20:52', '2023-07-14 08:20:52'),
(35, 28, '2023-07-14', '14:03:00', 'Ngong', '<p>we are working hard daily to make our service keep on moving</p>', '14:04:35', '2023-07-14 11:04:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
