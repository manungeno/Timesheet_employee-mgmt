<?php
include 'connection.php';

if(!empty($_POST["feedback"])){
    $feedback = $_POST["feedback"];
    $sql = "INSERT INTO feedback (message) VALUES ('$feedback')";
    $run = mysqli_query($connection, $sql);

    if($run){
        echo '1';
    }
}

