<?php
session_start();
include 'connection.php';

if(isset($_POST['submit']) && isset($_SESSION['id'])){
    $date = $_POST['date'];
    $timein = $_POST['timein'];
    $placeofwork = $_POST['placeOfWork'];
    $remarks = $_POST['remarks'];
    // $timeout = $_POST['timeout'];
    $employee_id = $_SESSION['id'];
    // date_default_timezone_set('Africa/Nairobi'); echo date('H:i:s');
    // $timeout = date('H;i:s');

    $sql = 'INSERT INTO report (employee_id, date, time_in, place_of_work, remarks) VALUES ("'.$employee_id.'", "'.$date.'", "'.$timein.'", "'.$placeofwork.'", "'.$remarks.'")';
    $run = mysqli_query($connection, $sql);

    if($run){
        $_SESSION['report-uploaded'] = 'Report successfully submitted!';
        echo '<script>window.location.assign("../index.php")</script>';
    }
    else{
        echo '<h4>Error happened</h4>';
    }

}
else{
    echo 'something is not set';
}