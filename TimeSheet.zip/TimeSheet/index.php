<!DOCTYPE html>
<?php session_start(); include 'server/connection.php' ?>
<html>
<head>
    <title>Time Sheet</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin/libraries/css/bootstrap.min.css">
    <link rel="stylesheet" href="./admin/libraries/fontawesome/css/all.css">
    <script src="./admin/libraries/jquery-3.6.0.min.js"></script>
    <script src="./admin/libraries/tinymce/tinymce.min.js"></script>
<?php
if(isset($_SESSION['username']) && (time() - $_SESSION['login-time']) <= 21600){
?>
    <div class="navbar px-3 pt-3">
        <div class="brand"><a href="/TimeSheet/">Daily Report</a></div>
        <div id="options"><a href="profile.php" class="mx-4"><i class="fa-solid fa-circle-user"></i> <?php echo $_SESSION['username'];?></a><a href="server/logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></div>
    </div><?php } else{ echo '<script>window.location.assign("login.php")</script>';}?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Signika+Negative:wght@500&display=swap');
        *{
            font-family: 'Signika Negative', sans-serif;
        }
        
        .navbar{
            background: rgb(0, 0, 69);
            display: flex;
            flex-direction: row;
            align-items: baseline;
            justify-content: space-between;
            height: fit-content;
        }
        .navbar .brand a{
            font-size: 20px;
            font-weight: 500;
        }
        .navbar a{
            text-decoration: none;
            color: #f2f2f2;
        }
        #outer{
            width: 95%;
            margin-left: 50%;
            transform: translateX(-50%);
            margin-top: 25px;
            height: 85%;
            position: fixed;
            background: #f5f5f5;
            border-radius: 5px;
            border: 1px solid #ececec;
            overflow-y: scroll;
            overflow-x: hidden;
        }
        #outer h4{
            width: 95%;
            border-bottom: 1px solid #d1d1d1;
            margin: 20px;
            padding-bottom: 7px;
        }
        #tasks{
            width: 80%;
            margin-left: 50%;
            transform: translateX(-50%);
        }
        #tasks > #row{
            width: 100%;
            display: flex;
            flex-direction: row;
            background: #fff;
            border: 1px solid #f3f3f3;
            box-shadow: 0 0 5px #c3c3c3;
            margin-bottom: 15px;
            padding: 7px;
            border-radius: 4px;
            height: 55px;
            overflow: hidden;
            transition: .3 ease-in-out;
        }
        #tasks > #row > #remarks{
            width: 70%;
        }
        /* #tasks > #row > #remarks p::after{
            content: "...";
        } */
        #tasks > #row >div p{
            line-height: 40px;
        }
        #tasks > #row #name button:focus{
            box-shadow: none;
            border-width: 0;
        }
        #tasks > #row >div:nth-child(1), #tasks > #row> div:nth-child(2), #tasks > #row> div:nth-child(3), #tasks > #row> div:nth-child(4){
            width: 20%;
        }
        #tasks > button{
            background: rgb(0, 0, 69);
            color: #fff;
        }
        #name button > .fa-minus{
            display: none;
        }
        .note{
            background: #ffebc6;
            padding: 10px;
            border-left: 5px solid #ffc558;
            width: fit-content;
            height: 45px;
            display: flex;
            justify-content: center;
            border-radius: 0 4px 4px 0;
        }
        .note p{
            display: flex;
            justify-content: center;
        }

        /*Responsiveness*/
        @media only screen and (max-width: 900px){
            .navbar a{
                font-size: 25px;
            }
            .navbar #options a{
                font-size: 18px;
            }
            #tasks{
                width: 97%;
            }
            #outer h4{
                font-size: 30px;
            }
            #tasks > #row >div:nth-child(1), #tasks > #row> div:nth-child(2), #tasks > #row> div:nth-child(3), #tasks > #row> div:nth-child(4){
                width: 25%;
            }
            #tasks > #row >div, #tasks > button{
                font-size: 20px;
            }
        }

        @media only screen and (max-width: 500px){
            .navbar a{
                font-size: 15px !important;
            }
            #tasks{
                width: 97%;
            }
            #outer h4{
                font-size: 20px;
            }
            #tasks > #row >div:nth-child(1), #tasks > #row> div:nth-child(2), #tasks > #row> div:nth-child(3), #tasks > #row> div:nth-child(4){
                width: 25%;
            }
            #tasks > #row >div, #tasks > button{
                font-size: 15px;
            }
        }
        .suggest{
            position: fixed;
            bottom: 0;
            right: 0;
            font-size: 35px;
            

        }
        .box{
            width: 350px;
            height: 300px;
            position: fixed;
            right: 65px;
            bottom: 24px;
            border: 2px solid;
            border-radius: 6px;
            box-shadow: 0 0 10px grey;
            display: none;
            overflow:hidden;
        }
        .box > h5{
            width: 100%;
            padding: 7px;
            background-color: whitesmoke;
            font-size: 16px;
            border-bottom: 2px solid black;
            margin: 0;
            height:15%;
            color: black;
        }
        .box textarea{
            width: 100%;
            outline: none;
            border: 0;
            resize: none;
            height: 85%;
            
        }
        .box > button{
            position: absolute;
            right: 25px;
            bottom: 10px;
            background-color:rgb(0, 0, 69);
            color:white ;
        }
        .box > button:hover{
                    color:white;
        }
        @media only screen and (max-width: 500px){
            .box{
                bottom: 60px;
                width: 90%;
                left:50%;
                transform: translateX(-50%)
            }
            .box > h5{
                font-size: 20px;
            }
        }

    </style>
</head>
<?php
//fetching employee's tasks
function employee_tasks(){
    global $connection;
    $id = $_SESSION['id'];
    $sql = "SELECT * FROM report WHERE employee_id = '$id' order by time_uploaded ASC";
    $run = mysqli_query($connection, $sql);
    $rows = mysqli_num_rows($run);
        if($rows > 0){
            while($details = mysqli_fetch_assoc($run)){?>

            <div id="row">
                <div id="name"><p><button class="btn btn-sm mb-1"><i class="fa-solid fa-plus"></i><i class="fa-solid fa-minus"></i></button><?php echo $details['date']?></p></div>
                <div class="working" id="working-hours"><p>From: <?php echo $details['time_in']?></p></div>
                <div class="working" id="working-hours"><p>To: <?php echo $details['timeout']?></p></div>
                <div id="placeofwork"><p><?php echo $details['place_of_work']?></p></div>
                <div id="remarks"><?php echo $details['remarks']?></div>
            </div>
            <?php }
        }
        else{?>
            <div id="row">No task...</div>
      <?php }
}
?>
<body>
    <div id="outer">
        <h4>Your Reports</h4>
        <div id="tasks">

            <!--submit notification-->
        <?php
        if (isset($_SESSION['report-uploaded'])) { ?>
            <div class="alert alert-success mt-2" role="alert">
                <strong>
                    <?php echo $_SESSION['report-uploaded']; ?>
                </strong>
            </div>
            <?php
            unset($_SESSION['report-uploaded']);
        } 
            //checking if an employee is approved
            $id = $_SESSION['id'];
            $sql = "SELECT approval FROM employee WHERE employee_id = '$id'";
            $run = mysqli_query($connection, $sql);
            $details = mysqli_fetch_assoc($run);

            //checking if submission was done today
            $sql2 = "SELECT report_id FROM report WHERE employee_id = $id AND date = CURDATE()";
            $run2 = mysqli_query($connection, $sql2);
            $report_rows = mysqli_num_rows($run2);

            if($details['approval'] == 'Not Approved'){?>
            <div class="note mb-2"><p>Wait for admin to approved you and the button bellow will be activated.</p></div><button disabled class="btn mb-3">New Report</button>
            <?php }
           else{?>
        <button class="btn mb-3">New Report</button> 
         <?php  }
            ?>
            <?php employee_tasks();?>
        </div>
        <div>
        <i class="fa-regular fa-comment-dots suggest btn" id="comment"></i>
        <div class="box">
            <h5>Feedback.<i style ="float: right;"class="fa-solid fa-xmark" id="close"></i></h5>
            <textarea name="" id="feedback" cols="30" rows="8" ></textarea>
            <button class="btn"><i class="fa-regular fa-paper-plane" id="feedback-submit"></i></button>
        </div>
    </div>
    </div>
   
</body>
<script>
     
            
    //expanding Tasks rows
    $(window).ready(function(){
        $(document).on('click', '#name button', function(){
            if($(this).closest('#row').height() <= 55){
                $(this).closest('#row').css('height', 'fit-content');
                $(this).children('.fa-plus').hide();
                $(this).children('.fa-minus').show();
            }
            else{
                $(this).closest('#row').css('height', '55px');
                $(this).children('.fa-plus').show();
                $(this).children('.fa-minus').hide();
            }
        })

        //submitting Feedback
        $('#feedback-submit').on('click', function(e){
            if($('#feedback').val() != ''){
                var feedback = $('#feedback').val();
                $.ajax({
                    type: 'post',
                    url: 'server/feedback.php',
                    data: {feedback: feedback},
                    success: function (response) {
                        if(response){
                            alert("Feedback sent successfully!");
                            location.reload();
                        }
                        else{
                            alert("Feedback submission failed!");
                        }
                    }
                })
            }
            else{
                e.preventDefault();
                alert('Write a feedback');
            }
        })

        //redirecting a page button click
        $('#tasks > button').on('click', function(){
            window.location.assign('report.php');
        })

        //removing some text on certain screen size
        var width = $(window).width();

        if(width <= 900){
            $('.working').hide();
        }


        // to display feedback

        $("#comment").on("click",function(){
           $(".box").toggle(); 
        })
        $(document).on("click", '#close' ,function(){
           $(".box").hide();
       
           }) 
    })
    
</script>
</html>